import { createContext } from "react";

const CountContext = createContext();

export default CountContext;
